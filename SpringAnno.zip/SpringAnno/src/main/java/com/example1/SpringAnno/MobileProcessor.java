package com.example1.SpringAnno;

public interface MobileProcessor 
{
	void process();
}
