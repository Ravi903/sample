package com.example1.DemoMVC1;

public interface Vehicle
{
	void drive();
}
