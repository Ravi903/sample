package com.airtel;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/add")
public class Addition extends HttpServlet
{
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException
	{
		
		int name=Integer.parseInt(req.getParameter("name"));
		int password=Integer.parseInt(req.getParameter("password"));
		
		int k=name+password;
		
		PrintWriter out= res.getWriter();
		//out.println("<html><body bgcolor='red'>");
		out.println("result is " + k);
		//out.print("</html></body>");
		
		
}
}
