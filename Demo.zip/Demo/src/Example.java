
public class Example {

	public static void main(String[] args) {

		int i,j,k;
		for(j=1;j<=5;j++)
		{
		for(i=1;i<=5-j+1;i++)
		{
			System.out.print("*");
		}
		System.out.println();
		}
	}

}
